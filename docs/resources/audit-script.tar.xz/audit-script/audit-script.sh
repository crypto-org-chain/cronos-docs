#!/bin/bash
trap review_ctrl_c INT

function review_ctrl_c() {
        echo "Encountered CTRL-C review output for completeness ..." 
	exit;
}

echo "################################################################################################"
echo "This Script Will Help Audit Your Linux Machine"
echo
echo "This script will execute speedtest-cli, lynis and perform some extra checks"
echo "Note: it has been tested for Ubuntu/Centos:"
echo
echo "Hostname: $HOSTNAME"
echo
echo "################################################################################################"

log_only="false"

print_usage() {
  echo "Usage: ./audit-script -l(log_only)"
  echo "-h		  			  show usage"
  echo "-l					  write output to log file"
}

while getopts 'l' flag; do
  case "${flag}" in
    l) log_only="true" ;;
    *) print_usage
       exit 1 ;;
  esac
done

echo
echo "[+] Executing Lynis"
echo "------------------------------------"
sudo chown -R 0:0 lynis
cd lynis
if [ "$log_only" = "true" ]; then
	sudo ./lynis audit system "--nocolors"
else
	sudo ./lynis audit system 
fi
cd ..
echo
echo "[+] Checking Kernel"
echo "------------------------------------"
sudo grep -Ei "no kernel update available" /var/log/lynis.log
sudo grep -Ei "os_kernel_version_full" /var/log/lynis-report.dat
echo
echo "[+] Checking Automatic Updates"
echo "------------------------------------"
sudo grep -Ei "unattended_upgrade_tool|unattended_upgrade_option" /var/log/lynis-report.dat
echo
echo "[+] Checking Security Framework"
echo "------------------------------------"
sudo grep -Ei "apparmor_enabled|apparmor_policy_loaded|selinux_status|selinux_mode|framework_selinux" /var/log/lynis-report.dat
echo
echo "[+] Checking Insecure Services/Vulnerable Programs"
echo "------------------------------------"
echo "Check Lynis Output"
echo
echo "[+] Checking GRUB"
echo "------------------------------------"
sudo grep -Ei "suggestion\[\]\=BOOT-5122" /var/log/lynis-report.dat
echo
echo "[+] Checking File Permissions"
echo "------------------------------------"
sudo grep -Ei "suggestion\[\]\=FILE-7524" /var/log/lynis-report.dat
echo "No Output is Positive"
echo
echo "[+] Check Blank Passwords"
echo "------------------------------------"
sudo grep -Ei "warning\[\]\=AUTH-9283" /var/log/lynis-report.dat
echo "No Output is Positive"
echo
echo "[+] Check Password Strength Tools"
echo "------------------------------------"
sudo grep -Ei "suggestion\[\]\=AUTH-9262" /var/log/lynis-report.dat
echo
echo "DEBIAN"
echo "common-auth"
sudo cat /etc/pam.d/common-auth
echo
echo "common-password"
sudo cat /etc/pam.d/common-password
echo
echo "CentOS-RHEL"
sudo cat /etc/pam.d/system-auth
sudo cat /etc/security/pwquality.conf
echo
echo "[+] Check IDS"
echo "------------------------------------"
sudo grep ids_ips_tooling /var/log/lynis-report.dat
echo "No Output Is Negative - Check Lynis Output for Software: System tooling"
echo
echo "[+] IPTables"
echo "------------------------------------"
echo "Check Lynis Output"
echo
echo "####################################"
echo "IPTables Rules For Manual Review"
echo "####################################"
sudo iptables -L
echo "####################################"
echo
echo
echo "[+] SSH"
echo "------------------------------------"
sudo grep -Ei "PermitRootLogin|PasswordAuthentication|ChallengeResponseAuthentication|UsePAM|AllowUsers|AllowGroups" /etc/ssh/sshd_config
echo
echo "[+] Check Docker File Permissions"
echo "------------------------------------"
echo "Check Lynis Output"
echo
echo "[+] Downloading and Executing Speedtest"
echo "------------------------------------"
chmod +x speedtest
./speedtest
echo
echo "################################################################################################"
echo "[Starting firewall scanning]"
p2pAnywhere=0
#CentOS built-in firewall firewalld scan
if command -v firewalld &> /dev/null;then
  firewalldStatus="$(sudo systemctl status firewalld | grep Active | cut -d " " -f 5)"
  case "${firewalldStatus}" in
    'active'*)    status=active;;
    'inactive'*)  status=inactive;;
    *)            status= unknown;;
  esac

  if [ $status != "active" ] && [ $status != "inactive" ]; then
    echo "unexpected error during ufw status checking"
    exit 1;
  fi

  echo "[Info] Your firewall is ${status}"

  if [[ $status = "active" || $status = "inactive" ]];
    then
      if [ $status = "inactive" ];then
        echo "[Warn] We advise you to enable host based firewall. If you have alternative, just ignore this warning."
      fi
      Services="$(sudo firewall-cmd --list-services)"
      for service in $Services
      do
        port=$(grep $service /etc/services | head -n 1 | awk '{print $2}' | sed 's/\/tcp//g')
        Rules="$Rules $port"
      done
      Ports="$(sudo firewall-cmd --list-port| sed 's/\/tcp//g')"
      for port in $Ports
      do
        Rules="$Rules $port"
      done
    else
      if ! command -v nft &> /dev/null
        then
          echo "[Warn] Command 'nft' not found."
          echo "[Error] Your ufw is not active yet. Please enable your firewall with 'sudo systemctl start firewalld' or use install nftable and then run the script again"
      fi
  fi
  openPort=0
  for port in $Rules
  do
    openPort=1
    process="$(sudo lsof -i -P -n | grep IPv4.**:$port.*LISTEN | cut -d " " -f 1)"
    if [ -z "$process" ];then
      echo "[Warn] No process detected to open this port $port (ipv4) rule. We advise you to delete this rule in firewalld/iptable/nftable."
    else
      echo "[Info] Detected port $port is open (ipv4) by process $process"
      service_port="$(sudo grep $port /etc/services | head -n1 | awk '{print $1}')"
      if [ ! -z "$service_port" ];then
        echo "[Info] This port may possibly serve for $service_port"
      fi
      firewalldRichRules="$(firewall-cmd --list-rich-rules | grep ssh.*accept)"
      if [ -z "$firewalldRichRules" ];then
        echo "[Warn] SSH port is opened connect from anywhere. We advise you to limit the source ip to reduce security risk."
        else
          firewalldRichRulesSSHforall="$(firewall-cmd --list-rich-rules | grep '0.0.0.0'.*ssh.*accept)"
          if [ -z "$firewalldRichRulesSSHforallssh" ]; then
            echo "[Info] Rich Rules are already set for SSH service. Please ensure you are already load the rules to firewall."
            else
              echo "[Warn] SSH port is opened connect from anywhere. We advise you to limit the source ip to reduce security risk."
          fi
       fi
    fi
  done
fi

#Ubuntu built-in firewall ufw scan 
if command -v ufw &> /dev/null;then
  ufwStatus="$(ufw status)"
  case "${ufwStatus}}" in
    'Status: active'*)     status=active;;
    'Status: inactive'*)   status=inactive;;
    *)                     status=unknown;;
  esac

  if [ $status != "active" ] && [ $status != "inactive" ]; then
    echo "unexpected error during ufw status checking"
    exit 1;
  fi

  echo "[Info] Your firewall is ${status}"

  if [[ $status = "active" || $status = "inactive" ]];
    then
      if [ $status = "inactive" ];then
        echo "[Warn] We advise you to enable host based firewall. If you have alternative, just ignore this warning."
      fi
      Rules="$((sudo ufw status | grep ALLOW | cut -d " " -f 1) | uniq)"
      Rulesv4="$(ufw status | grep ALLOW.*$port |grep -wv '(v6)' | cut -d " " -f 1| sed 's/\/tcp//g'| sort | uniq)"
      Rulesv6="$(ufw status | grep ALLOW.*$port.*'(v6)' | cut -d " " -f 1| sed 's/\/tcp//g'| sort | uniq)"
    else
      if ! command -v nft &> /dev/null
        then
          echo "[Warn] Command 'nft' not found."
          echo "[Error] Your ufw is not active yet. Please enable your firewall with 'sudo ufw enable' or use install nftable and then run the script again"
          exit 1
      fi
  fi

  for port in $Rulesv4
  do
    process="$(sudo lsof -i -P -n | grep IPv4.**:$port.*LISTEN | cut -d " " -f 1)"
    if [ -z "$process" ];then
      echo "[Warn] No process detected to open this port $port (ipv4) rule. We advise you to delete this rule in ufw/iptable/nftable."
    else
      echo "[Info] Detected port $port is open (ipv4) by process $process"
      service_port="$(sudo grep $port /etc/services | head -1 | cut -d $'\t' -f 1)"
      if [ ! -z "$service_port" ];then
        echo "[Info] This port may possibly serve for $service_port"
      fi
      if [ $process = 'sshd' ]; then
        # SSH port lookup
        sshrule="$(sudo ufw status | grep -wv '(v6)' | grep $port/tcp.*ALLOW.*Anywhere)"
        if [ ! -z "$sshrule" ];then
          echo "[Warn] SSH port is opened connect from anywhere. We advise you to limit the source ip to reduce security risk."
        fi
      fi
      if [ $port = '26656' ]; then
        # Cronos p2p port lookup
        p2prule="$(sudo ufw status | grep -wv '(v6)' | grep $port/tcp.*ALLOW.*Anywhere)"
        if [ ! -z "$p2prule" ];then
          p2pAnywhere=1
        fi
      fi
    fi
  done

  for port in $Rulesv6
  do
    openPort=1
    process="$(sudo lsof -i -P -n | grep IPv6.**:$port.*LISTEN | cut -d " " -f 1)"
    if [ -z "$process" ];then
      echo "[Warn] No process detected to open this port $port (ipv6) rule. We advise you to delete this rule in ufw/iptable/nftable."
      else
        echo "[Info] Detected port $port is open (ipv6) bt process $process"
        service_port="$(sudo grep $port /etc/services | head -1 | cut -d $'\t' -f 1)"
        if [ ! -z "$service_port" ];then
          echo "[Info] This port may possibly serve for $service_port"
        fi
        if [ $process = 'sshd' ]; then
          # SSH port lookup
          sshrule="$(sudo ufw status | grep $port/tcp.*'(v6)'.*ALLOW.*Anywhere)"
          if [ ! -z "$sshrule" ];then
            echo "[Warn] SSH port is opened connect from anywhere. We advise you to limit the source ip to reduce security risk."
          fi
       fi
       if [ $port = '26656' ]; then
         # Cronos p2p port lookup
         p2prule="$(sudo ufw status | grep $port/tcp.*'(v6)'.*ALLOW.*Anywhere)"
         if [ ! -z "$p2prule" ];then
           p2pAnywhere=1
         fi
       fi
    fi
  done
fi
echo "Firewall checking done."
echo "################################################################################################"
echo "[Starting services scanning]"
lsofResult="$(sudo lsof -i -P -n | grep *.*LISTEN | awk '{ print $9 }' | sed 's/\*://g'| tr ' ' '\n' | sort | uniq)"
custom_port="$(cut -d ' ' -f 2 ./customized_port.txt| sed 's/\/tcp//g')"

for port in $lsofResult
do
  IsCronosPort=0
  for cport in $custom_port
  do
    if [ $port = $cport ];then
      IsCronosPort=1
    fi
  done
  if [ $IsCronosPort = 0 ];
    then
      NonCronosPort="$NonCronosPort $port"
    else
      CronosPort="$CronosPort $port"
  fi
done

if [ -z "$CronosPort" ];then
  echo '------------------------------------------------------------------------------------------------'
  echo "Cronos Services Port: $CronosPort"
  echo '------------------------------------------------------------------------------------------------'
fi

for port in $CronosPort
do
  infirewall=0
  process="$(sudo lsof -i -P -n | grep *:$port.*LISTEN | cut -d " " -f 1 | head -n 1)"
  for fwport in $Rules
  do
    if [ $fwport = "$port/tcp" ];then
      infirewall=1
    fi
  done

  if [ $port = 26656 ];then
    if [ ! $infirewall = 1 ];
      then
        if [ $p2pAnywhere = 1 ];then
          echo "[Warn] For security best practices on validator node, we are suggested to limit the incoming traffic is from trusted ips for Cronos p2p port (tcp/26656)."
      else
        echo "[Error] For Cronos Node work properly, please ensure to allow tcp/26656 inbound traffic from trusted ips in your host based firewall."
      fi
    fi
  else
    if [ $infirewall = 1 ];then
      echo "[Info] Port $port is listening. We advise you to review once either the service is necessary or not or any configuration to close the port."
    else
      CronosService="$(grep $port ./customized_port.txt | cut -d ' ' -f 1)"
      echo "[Warn] $CronosService for Cronos enabled but not allowed in firewall rules. We advise to disable in configuration file when the service is not required."
    fi
  fi
done

if [ -z "$NonCronosPort" ];then
  echo '------------------------------------------------------------------------------------------------'
  echo "Non-Cronos Services Port: $NonCronosPort"
  echo '------------------------------------------------------------------------------------------------'
fi

for port in $NonCronosPort
do
  infirewall=0
  process="$(sudo lsof -i -P -n | grep *:$port.*LISTEN | cut -d " " -f 1 | head -n 1)"
  for fwport in $Rules
  do
    if [ $fwport = "$port/tcp" ];then
      infirewall=1
    fi
  done
  if [ $infirewall = 0 ];
    then
      echo "[Warn] Non-Cronos service detected! Port $port is opened by $process but not allowed in firewall ruleset."
      echo "[Info] We advise you to review once either the service is necessary or not or any configuration to close the port."
    else
      echo "[Warn] Non Cronos service detected! Port $port is opened by $process and allowed in firewall ruleset."
      echo "[Info] We advise you to review once either the service is necessary or not or any configuration to close the port."
  fi
done

echo 'Services checking done.'
echo '################################################################################################'
echo
echo "++++++++++++++AUDIT SCRIPT FINISHED++++++++++++++"
exit 0;